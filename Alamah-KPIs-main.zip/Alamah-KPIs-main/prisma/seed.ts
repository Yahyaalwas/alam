import { PrismaClient } from "../lib/generated/prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import bcrypt from "bcryptjs";

const adapter = new PrismaPg({ connectionString: process.env.DATABASE_URL! });
const prisma = new PrismaClient({ adapter });

async function main() {
  console.log("Seeding database...");

  const managerPass = await bcrypt.hash("manager123", 12);
  const empPass = await bcrypt.hash("employee123", 12);

  const manager = await prisma.user.upsert({
    where: { email: "manager@alamah.com" },
    update: {},
    create: {
      name: "Sara Al-Rashidi",
      email: "manager@alamah.com",
      password: managerPass,
      role: "manager",
      department: "Human Resources",
    },
  });

  const emp1 = await prisma.user.upsert({
    where: { email: "ahmed@alamah.com" },
    update: {},
    create: {
      name: "Ahmed Al-Farsi",
      email: "ahmed@alamah.com",
      password: empPass,
      role: "employee",
      department: "Marketing",
    },
  });

  const emp2 = await prisma.user.upsert({
    where: { email: "fatima@alamah.com" },
    update: {},
    create: {
      name: "Fatima Al-Zahra",
      email: "fatima@alamah.com",
      password: empPass,
      role: "employee",
      department: "Design",
    },
  });

  const emp3 = await prisma.user.upsert({
    where: { email: "khalid@alamah.com" },
    update: {},
    create: {
      name: "Khalid Al-Mansouri",
      email: "khalid@alamah.com",
      password: empPass,
      role: "employee",
      department: "Sales",
    },
  });

  const cycle = await prisma.performanceCycle.upsert({
    where: { id: "cycle-2025-h1" },
    update: {},
    create: {
      id: "cycle-2025-h1",
      title: "H1 2025 Performance Review",
      startDate: new Date("2025-01-01"),
      endDate: new Date("2025-06-30"),
      status: "ACTIVE",
    },
  });

  const goalTemplates = [
    {
      title: "Increase Brand Awareness",
      description: "Launch 3 major campaigns and achieve 20% increase in brand visibility metrics",
      weight: 20,
    },
    {
      title: "Customer Acquisition",
      description: "Acquire 150 new qualified leads per quarter through digital channels",
      weight: 20,
    },
    {
      title: "Project Delivery",
      description: "Deliver all assigned projects on time with <5% budget variance",
      weight: 20,
    },
  ];

  const compTemplates = [
    {
      title: "Communication & Collaboration",
      description: "Effectively communicates with team members and stakeholders at all levels",
      weight: 13.33,
    },
    {
      title: "Initiative & Innovation",
      description: "Proactively identifies problems and proposes creative solutions",
      weight: 13.33,
    },
    {
      title: "Leadership & Ownership",
      description: "Takes ownership of responsibilities and demonstrates leadership qualities",
      weight: 13.34,
    },
  ];

  for (const emp of [emp1, emp2, emp3]) {
    const existing = await prisma.performanceCard.findUnique({
      where: { userId_cycleId: { userId: emp.id, cycleId: cycle.id } },
    });

    if (!existing) {
      const card = await prisma.performanceCard.create({
        data: {
          userId: emp.id,
          cycleId: cycle.id,
          currentStage: "SELF_REVIEW",
        },
      });

      for (const g of goalTemplates) {
        await prisma.goal.create({
          data: { performanceCardId: card.id, ...g, type: "SMART" },
        });
      }

      for (const c of compTemplates) {
        await prisma.competency.create({
          data: { performanceCardId: card.id, ...c },
        });
      }
    }
  }

  console.log("✅ Seed complete!");
  console.log("\nLogin credentials:");
  console.log("  Manager:  manager@alamah.com / manager123");
  console.log("  Employee: ahmed@alamah.com / employee123");
  console.log("  Employee: fatima@alamah.com / employee123");
  console.log("  Employee: khalid@alamah.com / employee123");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
