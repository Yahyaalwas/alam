"use client";

import { useI18n } from "@/lib/i18n/context";
import { ratingToLabel } from "@/lib/score";
import type { GoalItem, CompetencyItem, RatingItem } from "@/types";

interface Props {
  index: number;
  item: GoalItem | CompetencyItem;
  rating: RatingItem | undefined;
  currentValue: { rating: number; comment: string } | undefined;
  onUpdate: (rating: number, comment: string) => void;
  selfLocked: boolean;
  managerLocked: boolean;
  fullyLocked: boolean;
  isEmployee: boolean;
  isManager: boolean;
  isActive: boolean;
  isFinalizing: boolean;
}

const RATINGS = [1, 2, 3, 4, 5];

export function RatingRow({
  index,
  item,
  rating,
  currentValue,
  onUpdate,
  selfLocked,
  managerLocked,
  fullyLocked,
  isEmployee,
  isManager,
  isActive,
  isFinalizing,
}: Props) {
  const { t } = useI18n();

  const employeeCanEdit = isEmployee && !selfLocked;
  const managerCanEdit = isManager && !managerLocked && !isFinalizing;
  const finalizeMode = isManager && isFinalizing && !fullyLocked;

  return (
    <div className="p-5 space-y-4">
      {/* Item header */}
      <div className="flex items-start gap-3">
        <span className="w-6 h-6 rounded-full bg-gray-100 text-gray-500 text-xs font-semibold flex items-center justify-center flex-shrink-0 mt-0.5">
          {index}
        </span>
        <div className="flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className="text-sm font-semibold text-gray-900">{item.title}</h3>
            <span className="text-xs text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full">
              {item.weight}%
            </span>
            {"type" in item && (
              <span className="text-xs text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">
                {item.type}
              </span>
            )}
          </div>
          <p className="text-xs text-gray-500 mt-1">{item.description}</p>
        </div>
      </div>

      {/* Rating columns */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Self Review column */}
        <RatingColumn
          title={t("selfRating")}
          ratingLabel={t("selfRating")}
          commentLabel={t("selfComment")}
          currentRating={employeeCanEdit ? currentValue?.rating ?? 0 : (rating?.employeeRating ?? 0)}
          currentComment={employeeCanEdit ? currentValue?.comment ?? "" : (rating?.employeeComment ?? "")}
          onChange={employeeCanEdit ? onUpdate : undefined}
          locked={selfLocked || isManager}
          show={true}
          placeholder="Describe your performance on this goal..."
        />

        {/* Manager Review column */}
        <RatingColumn
          title={t("managerRating")}
          ratingLabel={t("managerRating")}
          commentLabel={t("managerComment")}
          currentRating={managerCanEdit ? currentValue?.rating ?? 0 : (rating?.managerRating ?? 0)}
          currentComment={managerCanEdit ? currentValue?.comment ?? "" : (rating?.managerComment ?? "")}
          onChange={managerCanEdit ? onUpdate : undefined}
          locked={managerLocked || isEmployee || !selfLocked}
          show={selfLocked || isManager}
          placeholder="Provide your manager assessment..."
        />

        {/* Final / HR column */}
        <RatingColumn
          title={t("finalRating")}
          ratingLabel={t("finalRating")}
          commentLabel={t("finalComment")}
          currentRating={finalizeMode ? currentValue?.rating ?? 0 : (rating?.finalRating ?? 0)}
          currentComment={finalizeMode ? currentValue?.comment ?? "" : (rating?.finalComment ?? "")}
          onChange={finalizeMode ? onUpdate : undefined}
          locked={fullyLocked || isEmployee || !managerLocked}
          show={managerLocked || fullyLocked}
          placeholder="Enter calibrated final score..."
        />
      </div>
    </div>
  );
}

interface RatingColumnProps {
  title: string;
  ratingLabel: string;
  commentLabel: string;
  currentRating: number;
  currentComment: string;
  onChange: ((rating: number, comment: string) => void) | undefined;
  locked: boolean;
  show: boolean;
  placeholder: string;
}

function RatingColumn({
  title,
  currentRating,
  currentComment,
  onChange,
  locked,
  show,
  placeholder,
}: RatingColumnProps) {
  const { t } = useI18n();

  if (!show && locked) {
    return (
      <div className="p-3 rounded-lg bg-gray-50 border border-dashed border-gray-200">
        <p className="text-xs text-gray-300 text-center py-4">{title} pending</p>
      </div>
    );
  }

  const isEditable = !locked && !!onChange;

  return (
    <div className={`p-3 rounded-lg border ${locked && show ? "bg-gray-50 border-gray-100" : isEditable ? "bg-white border-gray-200" : "bg-gray-50 border-dashed border-gray-200"}`}>
      <p className="text-xs font-medium text-gray-500 mb-2">{title}</p>

      {/* Rating selector */}
      {isEditable ? (
        <div className="flex gap-1 mb-3">
          {RATINGS.map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => onChange(r, currentComment)}
              className={`flex-1 py-1.5 text-xs font-semibold rounded transition-all ${
                currentRating === r
                  ? "bg-[#E8630A] text-white shadow-sm"
                  : "bg-gray-100 text-gray-500 hover:bg-gray-200"
              }`}
            >
              {r}
            </button>
          ))}
        </div>
      ) : (
        <div className="flex items-center gap-2 mb-2">
          {currentRating > 0 ? (
            <>
              <span className="w-7 h-7 rounded-lg bg-[#E8630A] text-white text-sm font-bold flex items-center justify-center">
                {currentRating}
              </span>
              <span className="text-xs text-gray-600">{ratingToLabel(currentRating)}</span>
            </>
          ) : (
            <span className="text-xs text-gray-300">—</span>
          )}
        </div>
      )}

      {/* Rating label display when editing */}
      {isEditable && currentRating > 0 && (
        <p className="text-xs text-[#E8630A] font-medium mb-2">{ratingToLabel(currentRating)}</p>
      )}

      {/* Comment */}
      {isEditable ? (
        <textarea
          value={currentComment}
          onChange={(e) => onChange(currentRating, e.target.value)}
          placeholder={placeholder}
          rows={3}
          className="w-full text-xs text-gray-700 bg-gray-50 border border-gray-200 rounded-lg px-2 py-2 resize-none focus:outline-none focus:ring-2 focus:ring-[#E8630A]/20 focus:border-[#E8630A] transition-colors"
        />
      ) : (
        currentComment ? (
          <p className="text-xs text-gray-600 leading-relaxed">{currentComment}</p>
        ) : (
          <p className="text-xs text-gray-300 italic">No comment</p>
        )
      )}
    </div>
  );
}
