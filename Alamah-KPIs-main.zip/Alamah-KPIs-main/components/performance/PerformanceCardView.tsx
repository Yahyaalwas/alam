"use client";

import { useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { useI18n } from "@/lib/i18n/context";
import { useToast } from "@/components/ui/Toast";
import { Button } from "@/components/ui/Button";
import { StageBadge, CycleStatusBadge } from "@/components/ui/Badge";
import { ConfirmModal } from "@/components/ui/Modal";
import { RatingRow } from "./RatingRow";
import { calculateFinalScore, scoreToLabel } from "@/lib/score";
import type { PerformanceCardWithRelations } from "@/types";

interface CurrentUser {
  id: string;
  role: "employee" | "manager";
}

interface Props {
  card: PerformanceCardWithRelations;
  currentUser: CurrentUser;
}

type RatingsMap = Record<string, { rating: number; comment: string }>;

function buildInitialRatings(card: PerformanceCardWithRelations, role: "employee" | "manager"): RatingsMap {
  const map: RatingsMap = {};
  const allItems = [...card.goals, ...card.competencies];
  for (const item of allItems) {
    const r = card.ratings.find((rt) => rt.targetId === item.id);
    if (role === "employee") {
      map[item.id] = {
        rating: r?.employeeRating ?? 0,
        comment: r?.employeeComment ?? "",
      };
    } else if (role === "manager") {
      // If finalized, load final ratings; else load manager ratings
      const isFinalizing = card.currentStage === "HR_FINALIZED" && !card.hrFinalizedAt;
      map[item.id] = {
        rating: isFinalizing ? (r?.finalRating ?? r?.managerRating ?? 0) : (r?.managerRating ?? 0),
        comment: isFinalizing ? (r?.finalComment ?? r?.managerComment ?? "") : (r?.managerComment ?? ""),
      };
    }
  }
  return map;
}

export function PerformanceCardView({ card, currentUser }: Props) {
  const { t } = useI18n();
  const { toast } = useToast();
  const router = useRouter();

  const isEmployee = currentUser.role === "employee";
  const isManager = currentUser.role === "manager";

  const selfLocked = card.employeeSubmittedAt != null;
  const managerLocked = card.managerSubmittedAt != null;
  const fullyLocked = card.hrFinalizedAt != null;

  // Determine what the current user can edit
  const canEditSelf = isEmployee && !selfLocked;
  const canEditManager = isManager && card.currentStage === "MANAGER_REVIEW" && !managerLocked;
  const canFinalize = isManager && card.currentStage === "HR_FINALIZED" && !fullyLocked;

  const [ratings, setRatings] = useState<RatingsMap>(() => buildInitialRatings(card, currentUser.role));
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [saving, setSaving] = useState(false);

  const updateRating = useCallback((targetId: string, rating: number, comment: string) => {
    setRatings((prev) => ({ ...prev, [targetId]: { rating, comment } }));
  }, []);

  const saveDraft = async () => {
    setSaving(true);
    try {
      await fetch(`/api/performance-cards/${card.id}/save-draft`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ratings }),
      });
      toast(t("savedDraft"), "info");
    } catch {
      toast(t("errorOccurred"), "error");
    } finally {
      setSaving(false);
    }
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      let endpoint = "";
      if (canEditSelf) endpoint = "self-review";
      else if (canEditManager) endpoint = "manager-review";
      else if (canFinalize) endpoint = "finalize";

      const res = await fetch(`/api/performance-cards/${card.id}/${endpoint}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ratings }),
      });

      if (!res.ok) {
        const err = await res.json();
        toast(err.error || t("errorOccurred"), "error");
        return;
      }

      if (canEditSelf) toast(t("selfReviewSubmitted"), "success");
      else if (canEditManager) toast(t("managerReviewSubmitted"), "success");
      else toast(t("reviewFinalized"), "success");

      setConfirmOpen(false);
      router.refresh();
    } catch {
      toast(t("errorOccurred"), "error");
    } finally {
      setSubmitting(false);
    }
  };

  const allFilled = () => {
    const allIds = [...card.goals.map((g) => g.id), ...card.competencies.map((c) => c.id)];
    return allIds.every((id) => {
      const r = ratings[id];
      return r && r.rating >= 1 && r.comment.trim().length > 0;
    });
  };

  const previewScore = canEditSelf
    ? calculateFinalScore(card.goals, card.competencies, Object.entries(ratings).map(([targetId, r]) => ({
        id: "",
        performanceCardId: card.id,
        targetType: "goal",
        targetId,
        employeeRating: r.rating,
        employeeComment: r.comment,
        managerRating: null,
        managerComment: null,
        finalRating: null,
        finalComment: null,
        createdAt: new Date(),
      })))
    : null;

  const getConfirmMessage = () => {
    if (canEditSelf) return t("confirmSelfReview");
    if (canEditManager) return t("confirmManagerReview");
    return t("confirmFinalize");
  };

  const getSubmitLabel = () => {
    if (canEditSelf) return t("submitSelfReview");
    if (canEditManager) return t("submitManagerReview");
    if (canFinalize) return t("finalizeReview");
    return t("submitted");
  };

  return (
    <div className="space-y-6 max-w-4xl animate-fadeIn">
      {/* Back link */}
      <button
        onClick={() => router.back()}
        className="flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors"
      >
        <svg className="w-4 h-4 rtl:rotate-180" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
        </svg>
        Back
      </button>

      {/* Header */}
      <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
        <div className="flex items-start justify-between flex-wrap gap-3">
          <div>
            <h1 className="text-lg font-bold text-gray-900">{t("performanceCard")}</h1>
            <p className="text-sm text-gray-500 mt-0.5">
              {card.user.name} · {card.user.department}
            </p>
            <p className="text-xs text-gray-400 mt-1">{card.cycle.title}</p>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <CycleStatusBadge status={card.cycle.status} />
            <StageBadge stage={card.currentStage} />
            {fullyLocked && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-gray-100 text-gray-600 text-xs rounded-full border border-gray-200">
                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
                {t("locked")}
              </span>
            )}
          </div>
        </div>

        {/* Final score display */}
        {card.overallFinalScore != null && (
          <div className="mt-4 pt-4 border-t border-gray-50 flex items-center gap-4">
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-bold text-[#E8630A]">{card.overallFinalScore.toFixed(1)}%</span>
              <span className="text-sm text-gray-500">{scoreToLabel(card.overallFinalScore)}</span>
            </div>
          </div>
        )}

        {/* Preview score while editing */}
        {canEditSelf && previewScore !== null && (
          <div className="mt-4 pt-4 border-t border-gray-50">
            <p className="text-xs text-gray-400 mb-1">Preview Score</p>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-gray-700">{previewScore.toFixed(1)}%</span>
              <span className="text-sm text-gray-400">{scoreToLabel(previewScore)}</span>
            </div>
          </div>
        )}
      </div>

      {/* Weight breakdown info */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-blue-50 rounded-xl border border-blue-100 p-4">
          <p className="text-xs font-medium text-blue-600 mb-1">Goals Weight</p>
          <p className="text-2xl font-bold text-blue-700">60%</p>
          <p className="text-xs text-blue-500 mt-1">3 SMART objectives</p>
        </div>
        <div className="bg-purple-50 rounded-xl border border-purple-100 p-4">
          <p className="text-xs font-medium text-purple-600 mb-1">Competencies Weight</p>
          <p className="text-2xl font-bold text-purple-700">40%</p>
          <p className="text-xs text-purple-500 mt-1">3 behavioral competencies</p>
        </div>
      </div>

      {/* Goals section */}
      <Section title={t("goals")} subtitle="60% of total score" color="blue">
        {card.goals.map((goal, i) => (
          <RatingRow
            key={goal.id}
            index={i + 1}
            item={goal}
            rating={card.ratings.find((r) => r.targetId === goal.id)}
            currentValue={ratings[goal.id]}
            onUpdate={(rating, comment) => updateRating(goal.id, rating, comment)}
            selfLocked={selfLocked}
            managerLocked={managerLocked}
            fullyLocked={fullyLocked}
            isEmployee={isEmployee}
            isManager={isManager}
            isActive={canEditSelf || canEditManager || canFinalize}
            isFinalizing={canFinalize}
          />
        ))}
      </Section>

      {/* Competencies section */}
      <Section title={t("competencies")} subtitle="40% of total score" color="purple">
        {card.competencies.map((comp, i) => (
          <RatingRow
            key={comp.id}
            index={i + 1}
            item={comp}
            rating={card.ratings.find((r) => r.targetId === comp.id)}
            currentValue={ratings[comp.id]}
            onUpdate={(rating, comment) => updateRating(comp.id, rating, comment)}
            selfLocked={selfLocked}
            managerLocked={managerLocked}
            fullyLocked={fullyLocked}
            isEmployee={isEmployee}
            isManager={isManager}
            isActive={canEditSelf || canEditManager || canFinalize}
            isFinalizing={canFinalize}
          />
        ))}
      </Section>

      {/* Action bar */}
      {(canEditSelf || canEditManager || canFinalize) && (
        <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-4 flex items-center justify-between gap-4 sticky bottom-4">
          <div className="text-sm text-gray-500">
            {!allFilled() && (
              <span className="text-amber-600">Please rate and comment on all items</span>
            )}
            {allFilled() && (
              <span className="text-green-600">✓ All items completed</span>
            )}
          </div>
          <div className="flex items-center gap-3">
            <Button
              variant="secondary"
              size="sm"
              onClick={saveDraft}
              loading={saving}
            >
              Save Draft
            </Button>
            <Button
              size="sm"
              onClick={() => setConfirmOpen(true)}
              disabled={!allFilled()}
            >
              {getSubmitLabel()}
            </Button>
          </div>
        </div>
      )}

      <ConfirmModal
        open={confirmOpen}
        title={t("confirmSubmitTitle")}
        description={getConfirmMessage()}
        confirmLabel={canFinalize ? t("yesFinalize") : t("yes")}
        cancelLabel={t("cancel")}
        onConfirm={handleSubmit}
        onCancel={() => setConfirmOpen(false)}
        loading={submitting}
      />
    </div>
  );
}

function Section({
  title,
  subtitle,
  color,
  children,
}: {
  title: string;
  subtitle: string;
  color: "blue" | "purple";
  children: React.ReactNode;
}) {
  const colors = {
    blue: "border-blue-100 bg-blue-50/30",
    purple: "border-purple-100 bg-purple-50/30",
  };
  const headerColors = {
    blue: "text-blue-700",
    purple: "text-purple-700",
  };

  return (
    <div className={`bg-white rounded-xl border shadow-sm overflow-hidden ${colors[color]}`}>
      <div className="px-5 py-4 border-b border-gray-50">
        <h2 className={`text-sm font-semibold ${headerColors[color]}`}>{title}</h2>
        <p className="text-xs text-gray-400 mt-0.5">{subtitle}</p>
      </div>
      <div className="divide-y divide-gray-50">{children}</div>
    </div>
  );
}
