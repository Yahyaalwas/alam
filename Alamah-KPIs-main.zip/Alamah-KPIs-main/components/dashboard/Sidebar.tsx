"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useI18n } from "@/lib/i18n/context";
import { clsx } from "clsx";
import type { AuthUser } from "@/types";

interface SidebarProps {
  user: AuthUser;
}

interface NavItem {
  href: string;
  labelKey: "dashboard" | "myReview" | "employees";
  icon: React.ReactNode;
  roles: ("employee" | "manager")[];
}

const navItems: NavItem[] = [
  {
    href: "/dashboard/employee",
    labelKey: "dashboard",
    roles: ["employee"],
    icon: (
      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
      </svg>
    ),
  },
  {
    href: "/dashboard/manager",
    labelKey: "dashboard",
    roles: ["manager"],
    icon: (
      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
      </svg>
    ),
  },
];

export function Sidebar({ user }: SidebarProps) {
  const { t } = useI18n();
  const pathname = usePathname();

  const visibleItems = navItems.filter((item) => item.roles.includes(user.role as "employee" | "manager"));

  return (
    <nav className="w-56 bg-white border-e border-gray-100 flex flex-col py-4 shrink-0 hidden md:flex">
      <div className="px-3 space-y-0.5">
        {visibleItems.map((item) => {
          const active = pathname === item.href || pathname.startsWith(item.href + "/");
          return (
            <Link
              key={item.href}
              href={item.href}
              className={clsx(
                "flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors",
                active
                  ? "bg-orange-50 text-[#E8630A] font-medium"
                  : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
              )}
            >
              <span className={active ? "text-[#E8630A]" : "text-gray-400"}>{item.icon}</span>
              {t(item.labelKey)}
            </Link>
          );
        })}
      </div>

      {/* Department chip at bottom */}
      <div className="mt-auto px-4 pb-2">
        <div className="px-3 py-2 rounded-lg bg-gray-50">
          <p className="text-xs text-gray-400">Department</p>
          <p className="text-xs font-medium text-gray-700 truncate">{user.department}</p>
        </div>
      </div>
    </nav>
  );
}
