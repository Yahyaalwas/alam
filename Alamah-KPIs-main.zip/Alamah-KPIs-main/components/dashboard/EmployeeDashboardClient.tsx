"use client";

import Link from "next/link";
import { useI18n } from "@/lib/i18n/context";
import { StageBadge, CycleStatusBadge } from "@/components/ui/Badge";
import { calculateFinalScore, scoreToLabel } from "@/lib/score";
import type { PerformanceCardWithRelations } from "@/types";

interface Props {
  card: PerformanceCardWithRelations | null;
  userId: string;
  userName: string;
}

export function EmployeeDashboardClient({ card, userName }: Props) {
  const { t } = useI18n();

  const selfCompleted = card?.employeeSubmittedAt != null;
  const managerCompleted = card?.managerSubmittedAt != null;
  const finalized = card?.hrFinalizedAt != null;

  const steps = [
    { label: t("selfReview"), done: selfCompleted },
    { label: t("managerReview"), done: managerCompleted },
    { label: t("hrFinalized"), done: finalized },
  ];

  const currentStep = finalized ? 3 : managerCompleted ? 2 : selfCompleted ? 1 : 0;

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-gray-900">
          {t("dashboard")}
        </h1>
        <p className="text-sm text-gray-500 mt-0.5">
          Welcome back, <span className="font-medium text-gray-700">{userName}</span>
        </p>
      </div>

      {!card ? (
        <EmptyState message={t("noCard")} />
      ) : (
        <>
          {/* Cycle info */}
          <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
            <div className="flex items-start justify-between flex-wrap gap-3">
              <div>
                <p className="text-xs font-medium text-gray-400 uppercase tracking-wide">{t("currentCycle")}</p>
                <h2 className="text-base font-semibold text-gray-900 mt-1">{card.cycle.title}</h2>
                <p className="text-xs text-gray-500 mt-0.5">
                  {new Date(card.cycle.startDate).toLocaleDateString()} —{" "}
                  {new Date(card.cycle.endDate).toLocaleDateString()}
                </p>
              </div>
              <CycleStatusBadge status={card.cycle.status} />
            </div>
          </div>

          {/* Progress steps */}
          <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
            <p className="text-xs font-medium text-gray-400 uppercase tracking-wide mb-4">{t("stage")}</p>
            <div className="flex items-center gap-0">
              {steps.map((step, i) => (
                <div key={i} className="flex items-center flex-1 last:flex-none">
                  <div className="flex flex-col items-center gap-1.5">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold border-2 transition-all ${
                        step.done
                          ? "bg-[#E8630A] border-[#E8630A] text-white"
                          : i === currentStep
                          ? "border-[#E8630A] text-[#E8630A] bg-orange-50"
                          : "border-gray-200 text-gray-400 bg-gray-50"
                      }`}
                    >
                      {step.done ? "✓" : i + 1}
                    </div>
                    <span
                      className={`text-xs text-center leading-tight ${
                        step.done || i === currentStep ? "text-gray-700 font-medium" : "text-gray-400"
                      }`}
                    >
                      {step.label}
                    </span>
                  </div>
                  {i < steps.length - 1 && (
                    <div
                      className={`flex-1 h-0.5 mx-2 mb-5 transition-colors ${
                        step.done ? "bg-[#E8630A]" : "bg-gray-200"
                      }`}
                    />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Card summary */}
          <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
            <div className="flex items-center justify-between mb-4">
              <p className="text-xs font-medium text-gray-400 uppercase tracking-wide">{t("myPerformanceCard")}</p>
              <StageBadge stage={card.currentStage} />
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-5">
              <Stat label={t("goals")} value={`${card.goals.length}`} sub="objectives" />
              <Stat label={t("competencies")} value={`${card.competencies.length}`} sub="behaviors" />
              <Stat
                label={t("status")}
                value={selfCompleted ? t("submitted") : "Pending"}
                highlight={selfCompleted}
              />
              <Stat
                label={t("finalScore")}
                value={
                  card.overallFinalScore != null
                    ? `${card.overallFinalScore.toFixed(1)}%`
                    : "—"
                }
                sub={card.overallFinalScore != null ? scoreToLabel(card.overallFinalScore) : undefined}
              />
            </div>

            <Link
              href={`/performance/${card.id}`}
              className="inline-flex items-center gap-2 px-4 py-2 bg-[#E8630A] text-white text-sm font-medium rounded-lg hover:bg-[#c5520a] transition-colors"
            >
              {selfCompleted ? "View My Review" : t("submitSelfReview")}
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </Link>
          </div>
        </>
      )}
    </div>
  );
}

function Stat({ label, value, sub, highlight }: { label: string; value: string; sub?: string; highlight?: boolean }) {
  return (
    <div className="p-3 rounded-lg bg-gray-50">
      <p className="text-xs text-gray-400 mb-1">{label}</p>
      <p className={`text-lg font-bold ${highlight ? "text-green-600" : "text-gray-900"}`}>{value}</p>
      {sub && <p className="text-xs text-gray-400 mt-0.5">{sub}</p>}
    </div>
  );
}

function EmptyState({ message }: { message: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center mb-4">
        <svg className="w-7 h-7 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
        </svg>
      </div>
      <p className="text-sm text-gray-500">{message}</p>
    </div>
  );
}
