"use client";

import { useState } from "react";
import Link from "next/link";
import { useI18n } from "@/lib/i18n/context";
import { StageBadge, CycleStatusBadge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { scoreToLabel } from "@/lib/score";
import type { PerformanceCardWithRelations } from "@/types";

interface Props {
  cards: PerformanceCardWithRelations[];
  managerName: string;
}

export function ManagerDashboardClient({ cards, managerName }: Props) {
  const { t } = useI18n();
  const [search, setSearch] = useState("");
  const [stageFilter, setStageFilter] = useState<string>("all");

  const filtered = cards.filter((card) => {
    const matchSearch =
      card.user.name.toLowerCase().includes(search.toLowerCase()) ||
      card.user.department.toLowerCase().includes(search.toLowerCase());
    const matchStage = stageFilter === "all" || card.currentStage === stageFilter;
    return matchSearch && matchStage;
  });

  const stats = {
    total: cards.length,
    selfReview: cards.filter((c) => c.currentStage === "SELF_REVIEW").length,
    managerReview: cards.filter((c) => c.currentStage === "MANAGER_REVIEW" && !c.managerSubmittedAt).length,
    finalized: cards.filter((c) => c.hrFinalizedAt != null).length,
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-gray-900">{t("allEmployees")}</h1>
        <p className="text-sm text-gray-500 mt-0.5">
          Welcome back, <span className="font-medium text-gray-700">{managerName}</span>
        </p>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <StatCard label="Total Reviews" value={stats.total} color="gray" />
        <StatCard label="Pending Self-Review" value={stats.selfReview} color="blue" />
        <StatCard label="Awaiting Manager" value={stats.managerReview} color="orange" />
        <StatCard label="Finalized" value={stats.finalized} color="green" />
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
        {/* Table header with filters */}
        <div className="p-4 border-b border-gray-50 flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            placeholder="Search employees..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="flex-1 px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E8630A]/30 focus:border-[#E8630A]"
          />
          <select
            value={stageFilter}
            onChange={(e) => setStageFilter(e.target.value)}
            className="px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E8630A]/30 focus:border-[#E8630A] bg-white"
          >
            <option value="all">All Stages</option>
            <option value="SELF_REVIEW">Self Review</option>
            <option value="MANAGER_REVIEW">Manager Review</option>
            <option value="HR_FINALIZED">Finalized</option>
          </select>
        </div>

        {filtered.length === 0 ? (
          <div className="py-16 text-center">
            <p className="text-sm text-gray-400">{t("noEmployees")}</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-50">
                  <th className="text-start px-4 py-3 text-xs font-medium text-gray-400 uppercase tracking-wide">{t("employee")}</th>
                  <th className="text-start px-4 py-3 text-xs font-medium text-gray-400 uppercase tracking-wide hidden sm:table-cell">{t("department")}</th>
                  <th className="text-start px-4 py-3 text-xs font-medium text-gray-400 uppercase tracking-wide">{t("stage")}</th>
                  <th className="text-start px-4 py-3 text-xs font-medium text-gray-400 uppercase tracking-wide hidden md:table-cell">{t("finalScore")}</th>
                  <th className="text-start px-4 py-3 text-xs font-medium text-gray-400 uppercase tracking-wide">{t("actions")}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {filtered.map((card) => (
                  <tr key={card.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center text-[#E8630A] text-xs font-semibold flex-shrink-0">
                          {card.user.name.charAt(0)}
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">{card.user.name}</p>
                          <p className="text-xs text-gray-400 sm:hidden">{card.user.department}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-gray-600 hidden sm:table-cell">{card.user.department}</td>
                    <td className="px-4 py-3">
                      <StageBadge stage={card.currentStage} />
                    </td>
                    <td className="px-4 py-3 hidden md:table-cell">
                      {card.overallFinalScore != null ? (
                        <div>
                          <span className="font-semibold text-gray-900">
                            {card.overallFinalScore.toFixed(1)}%
                          </span>
                          <span className="text-xs text-gray-400 ms-1">
                            {scoreToLabel(card.overallFinalScore)}
                          </span>
                        </div>
                      ) : (
                        <span className="text-gray-400">—</span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <Link
                        href={`/performance/${card.id}`}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#E8630A] bg-orange-50 rounded-lg hover:bg-orange-100 transition-colors"
                      >
                        {t("viewCard")}
                        <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                        </svg>
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

function StatCard({ label, value, color }: { label: string; value: number; color: "gray" | "blue" | "orange" | "green" }) {
  const colors = {
    gray: "bg-gray-50 text-gray-700",
    blue: "bg-blue-50 text-blue-700",
    orange: "bg-orange-50 text-[#E8630A]",
    green: "bg-green-50 text-green-700",
  };
  return (
    <div className={`rounded-xl p-4 ${colors[color]}`}>
      <p className="text-2xl font-bold">{value}</p>
      <p className="text-xs font-medium mt-1 opacity-70">{label}</p>
    </div>
  );
}
