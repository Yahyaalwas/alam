import { clsx } from "clsx";
import type { PerformanceStage, PerformanceCycleStatus } from "@/types";

interface BadgeProps {
  children: React.ReactNode;
  variant?: "orange" | "blue" | "green" | "gray" | "red" | "yellow";
  className?: string;
}

export function Badge({ children, variant = "gray", className }: BadgeProps) {
  const variants = {
    orange: "bg-orange-100 text-orange-700 border-orange-200",
    blue: "bg-blue-100 text-blue-700 border-blue-200",
    green: "bg-green-100 text-green-700 border-green-200",
    gray: "bg-gray-100 text-gray-600 border-gray-200",
    red: "bg-red-100 text-red-700 border-red-200",
    yellow: "bg-yellow-100 text-yellow-700 border-yellow-200",
  };

  return (
    <span
      className={clsx(
        "inline-flex items-center px-2 py-0.5 text-xs font-medium rounded-full border",
        variants[variant],
        className
      )}
    >
      {children}
    </span>
  );
}

export function StageBadge({ stage }: { stage: PerformanceStage }) {
  const config: Record<PerformanceStage, { label: string; variant: BadgeProps["variant"] }> = {
    SELF_REVIEW: { label: "Self Review", variant: "blue" },
    MANAGER_REVIEW: { label: "Manager Review", variant: "orange" },
    HR_FINALIZED: { label: "Finalized", variant: "green" },
  };
  const { label, variant } = config[stage];
  return <Badge variant={variant}>{label}</Badge>;
}

export function CycleStatusBadge({ status }: { status: PerformanceCycleStatus }) {
  const config: Record<PerformanceCycleStatus, { label: string; variant: BadgeProps["variant"] }> = {
    ACTIVE: { label: "Active", variant: "green" },
    DRAFT: { label: "Draft", variant: "gray" },
    CLOSED: { label: "Closed", variant: "red" },
  };
  const { label, variant } = config[status];
  return <Badge variant={variant}>{label}</Badge>;
}
