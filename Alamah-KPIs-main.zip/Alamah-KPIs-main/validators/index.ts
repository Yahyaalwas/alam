import { z } from "zod";

export const loginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export const ratingEntrySchema = z.object({
  rating: z.number().min(1).max(5),
  comment: z.string().min(1, "Comment is required").max(1000),
});

export const selfReviewSchema = z.object({
  ratings: z.record(z.string(), ratingEntrySchema),
});

export const managerReviewSchema = z.object({
  ratings: z.record(z.string(), ratingEntrySchema),
});

export const hrFinalizeSchema = z.object({
  ratings: z.record(z.string(), z.object({
    rating: z.number().min(1).max(5),
    comment: z.string().min(1).max(1000),
  })),
});

export type LoginInput = z.infer<typeof loginSchema>;
export type SelfReviewInput = z.infer<typeof selfReviewSchema>;
export type ManagerReviewInput = z.infer<typeof managerReviewSchema>;
export type HrFinalizeInput = z.infer<typeof hrFinalizeSchema>;
