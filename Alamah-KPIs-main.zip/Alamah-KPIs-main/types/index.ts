import type { Role, PerformanceCycleStatus, PerformanceStage } from "@/lib/generated/prisma/enums";

export type { Role, PerformanceCycleStatus, PerformanceStage };

export interface JWTPayload {
  userId: string;
  email: string;
  role: Role;
  name: string;
}

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: Role;
  department: string;
}

export interface PerformanceCardWithRelations {
  id: string;
  userId: string;
  cycleId: string;
  overallFinalScore: number | null;
  currentStage: PerformanceStage;
  employeeSubmittedAt: Date | null;
  managerSubmittedAt: Date | null;
  hrFinalizedAt: Date | null;
  createdAt: Date;
  user: {
    id: string;
    name: string;
    email: string;
    department: string;
    role: Role;
  };
  cycle: {
    id: string;
    title: string;
    startDate: Date;
    endDate: Date;
    status: PerformanceCycleStatus;
  };
  goals: GoalItem[];
  competencies: CompetencyItem[];
  ratings: RatingItem[];
}

export interface GoalItem {
  id: string;
  performanceCardId: string;
  title: string;
  description: string;
  weight: number;
  type: string;
  createdAt: Date;
}

export interface CompetencyItem {
  id: string;
  performanceCardId: string;
  title: string;
  description: string;
  weight: number;
  createdAt: Date;
}

export interface RatingItem {
  id: string;
  performanceCardId: string;
  targetType: string;
  targetId: string;
  employeeRating: number | null;
  employeeComment: string | null;
  managerRating: number | null;
  managerComment: string | null;
  finalRating: number | null;
  finalComment: string | null;
  createdAt: Date;
}

export interface RatingFormData {
  [targetId: string]: {
    rating: number;
    comment: string;
  };
}
