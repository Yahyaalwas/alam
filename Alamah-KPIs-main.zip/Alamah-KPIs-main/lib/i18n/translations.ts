export const translations = {
  en: {
    // General
    appName: "ALAMAH PMS",
    loading: "Loading...",
    save: "Save",
    submit: "Submit",
    cancel: "Cancel",
    confirm: "Confirm",
    logout: "Logout",
    language: "Language",

    // Auth
    login: "Login",
    loginTitle: "Sign in to ALAMAH PMS",
    email: "Email Address",
    password: "Password",
    loggingIn: "Signing in...",
    invalidCredentials: "Invalid email or password",

    // Navigation
    dashboard: "Dashboard",
    myReview: "My Review",
    employees: "Employees",
    settings: "Settings",

    // Performance stages
    selfReview: "Self Review",
    managerReview: "Manager Review",
    hrFinalized: "HR Finalized",

    // Dashboard
    currentCycle: "Current Cycle",
    myPerformanceCard: "My Performance Card",
    status: "Status",
    stage: "Stage",
    finalScore: "Final Score",
    noCycle: "No active performance cycle",
    noCard: "No performance card assigned",

    // Manager dashboard
    allEmployees: "All Employees",
    employee: "Employee",
    department: "Department",
    completion: "Completion",
    actions: "Actions",
    viewCard: "View Card",

    // Performance card
    performanceCard: "Performance Card",
    goals: "Goals (60%)",
    competencies: "Competencies (40%)",
    selfRating: "Self Rating",
    selfComment: "Self Comment",
    managerRating: "Manager Rating",
    managerComment: "Manager Comment",
    finalRating: "Final Rating",
    finalComment: "Final Comment",
    weight: "Weight",
    submitSelfReview: "Submit Self Review",
    submitManagerReview: "Submit Manager Review",
    finalizeReview: "Finalize Review",
    submitting: "Submitting...",
    submitted: "Submitted",
    locked: "Locked",

    // Rating labels
    rating1: "Unsatisfactory",
    rating2: "Needs Improvement",
    rating3: "Meets Expectations",
    rating4: "Exceeds Expectations",
    rating5: "Exceptional",
    selectRating: "Select rating",

    // Confirmation modal
    confirmSubmitTitle: "Confirm Submission",
    confirmSelfReview: "Once submitted, your self-review will be locked and cannot be edited. Are you sure?",
    confirmManagerReview: "Once submitted, your manager review will be locked and cannot be edited. Are you sure?",
    confirmFinalize: "Once finalized, the entire performance card will be permanently locked. Are you sure?",
    yes: "Yes, Submit",
    yesFinalize: "Yes, Finalize",

    // Toast messages
    selfReviewSubmitted: "Self-review submitted successfully",
    managerReviewSubmitted: "Manager review submitted successfully",
    reviewFinalized: "Review finalized successfully",
    errorOccurred: "An error occurred. Please try again.",
    savedDraft: "Draft saved",

    // Score labels
    exceptional: "Exceptional",
    exceedsExpectations: "Exceeds Expectations",
    meetsExpectations: "Meets Expectations",
    needsImprovement: "Needs Improvement",
    unsatisfactory: "Unsatisfactory",

    // Cycle status
    active: "Active",
    draft: "Draft",
    closed: "Closed",

    // Empty states
    noEmployees: "No employees found",
    noData: "No data available",
  },
  ar: {
    // General
    appName: "نظام علامة لإدارة الأداء",
    loading: "جارٍ التحميل...",
    save: "حفظ",
    submit: "إرسال",
    cancel: "إلغاء",
    confirm: "تأكيد",
    logout: "تسجيل الخروج",
    language: "اللغة",

    // Auth
    login: "تسجيل الدخول",
    loginTitle: "تسجيل الدخول إلى نظام علامة لإدارة الأداء",
    email: "البريد الإلكتروني",
    password: "كلمة المرور",
    loggingIn: "جارٍ تسجيل الدخول...",
    invalidCredentials: "البريد الإلكتروني أو كلمة المرور غير صحيحة",

    // Navigation
    dashboard: "لوحة التحكم",
    myReview: "مراجعتي",
    employees: "الموظفون",
    settings: "الإعدادات",

    // Performance stages
    selfReview: "التقييم الذاتي",
    managerReview: "مراجعة المدير",
    hrFinalized: "اعتماد الموارد البشرية",

    // Dashboard
    currentCycle: "الدورة الحالية",
    myPerformanceCard: "بطاقة أدائي",
    status: "الحالة",
    stage: "المرحلة",
    finalScore: "النتيجة النهائية",
    noCycle: "لا توجد دورة تقييم نشطة",
    noCard: "لا توجد بطاقة أداء مخصصة",

    // Manager dashboard
    allEmployees: "جميع الموظفين",
    employee: "الموظف",
    department: "القسم",
    completion: "الإتمام",
    actions: "الإجراءات",
    viewCard: "عرض البطاقة",

    // Performance card
    performanceCard: "بطاقة الأداء",
    goals: "الأهداف (٦٠٪)",
    competencies: "الكفاءات (٤٠٪)",
    selfRating: "التقييم الذاتي",
    selfComment: "التعليق الذاتي",
    managerRating: "تقييم المدير",
    managerComment: "تعليق المدير",
    finalRating: "التقييم النهائي",
    finalComment: "التعليق النهائي",
    weight: "الوزن",
    submitSelfReview: "إرسال التقييم الذاتي",
    submitManagerReview: "إرسال مراجعة المدير",
    finalizeReview: "اعتماد المراجعة",
    submitting: "جارٍ الإرسال...",
    submitted: "تم الإرسال",
    locked: "مقفل",

    // Rating labels
    rating1: "غير مرضٍ",
    rating2: "يحتاج تحسين",
    rating3: "يلبي التوقعات",
    rating4: "يتجاوز التوقعات",
    rating5: "استثنائي",
    selectRating: "اختر التقييم",

    // Confirmation modal
    confirmSubmitTitle: "تأكيد الإرسال",
    confirmSelfReview: "بعد الإرسال، سيتم قفل تقييمك الذاتي ولا يمكن تعديله. هل أنت متأكد؟",
    confirmManagerReview: "بعد الإرسال، سيتم قفل مراجعة المدير ولا يمكن تعديلها. هل أنت متأكد؟",
    confirmFinalize: "بعد الاعتماد، سيتم قفل بطاقة الأداء بشكل دائم. هل أنت متأكد؟",
    yes: "نعم، إرسال",
    yesFinalize: "نعم، اعتماد",

    // Toast messages
    selfReviewSubmitted: "تم إرسال التقييم الذاتي بنجاح",
    managerReviewSubmitted: "تم إرسال مراجعة المدير بنجاح",
    reviewFinalized: "تم اعتماد المراجعة بنجاح",
    errorOccurred: "حدث خطأ. يرجى المحاولة مرة أخرى.",
    savedDraft: "تم حفظ المسودة",

    // Score labels
    exceptional: "استثنائي",
    exceedsExpectations: "يتجاوز التوقعات",
    meetsExpectations: "يلبي التوقعات",
    needsImprovement: "يحتاج تحسين",
    unsatisfactory: "غير مرضٍ",

    // Cycle status
    active: "نشط",
    draft: "مسودة",
    closed: "مغلق",

    // Empty states
    noEmployees: "لا يوجد موظفون",
    noData: "لا توجد بيانات متاحة",
  },
} as const;

export type Language = "en" | "ar";
export type TranslationKey = keyof typeof translations.en;
