import type { GoalItem, CompetencyItem, RatingItem } from "@/types";

/**
 * Calculates final score:
 * - Goals contribute 60% (3 goals × 20% each)
 * - Competencies contribute 40% (3 competencies × ~13.33% each)
 * Rating scale: 1–5, normalized to percentage
 */
export function calculateFinalScore(
  goals: GoalItem[],
  competencies: CompetencyItem[],
  ratings: RatingItem[],
  useManagerRatings = false
): number | null {
  const getRating = (id: string): number | null => {
    const r = ratings.find((r) => r.targetId === id);
    if (!r) return null;
    if (useManagerRatings) return r.finalRating ?? r.managerRating ?? null;
    return r.employeeRating ?? null;
  };

  let goalScore = 0;
  let goalWeightSum = 0;
  for (const goal of goals) {
    const rating = getRating(goal.id);
    if (rating === null) return null;
    goalScore += (rating / 5) * goal.weight;
    goalWeightSum += goal.weight;
  }

  let compScore = 0;
  let compWeightSum = 0;
  for (const comp of competencies) {
    const rating = getRating(comp.id);
    if (rating === null) return null;
    compScore += (rating / 5) * comp.weight;
    compWeightSum += comp.weight;
  }

  if (goalWeightSum === 0 || compWeightSum === 0) return null;

  // Normalize goal portion to 60 and competency portion to 40
  const normalizedGoal = goalWeightSum > 0 ? (goalScore / goalWeightSum) * 60 : 0;
  const normalizedComp = compWeightSum > 0 ? (compScore / compWeightSum) * 40 : 0;

  return Math.round((normalizedGoal + normalizedComp) * 100) / 100;
}

export function scoreToLabel(score: number): string {
  if (score >= 90) return "Exceptional";
  if (score >= 75) return "Exceeds Expectations";
  if (score >= 60) return "Meets Expectations";
  if (score >= 40) return "Needs Improvement";
  return "Unsatisfactory";
}

export function ratingToLabel(rating: number): string {
  const labels: Record<number, string> = {
    1: "Unsatisfactory",
    2: "Needs Improvement",
    3: "Meets Expectations",
    4: "Exceeds Expectations",
    5: "Exceptional",
  };
  return labels[rating] ?? "—";
}
