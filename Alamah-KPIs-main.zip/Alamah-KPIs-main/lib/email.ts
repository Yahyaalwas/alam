import { Resend } from "resend";

const FROM = "ALAMAH PMS <noreply@alamahmarketing.com>";

export async function sendEmployeeSubmittedEmail(opts: {
  managerEmail: string;
  managerName: string;
  employeeName: string;
  cycleName: string;
}) {
  const resend = new Resend(process.env.RESEND_API_KEY);
  await resend.emails.send({
    from: FROM,
    to: opts.managerEmail,
    subject: `[ALAMAH PMS] ${opts.employeeName} submitted self-review`,
    html: `
      <p>Hi ${opts.managerName},</p>
      <p><strong>${opts.employeeName}</strong> has submitted their self-review for the <strong>${opts.cycleName}</strong> cycle.</p>
      <p>Please log in to ALAMAH PMS to complete your manager review.</p>
    `,
  });
}

export async function sendManagerSubmittedEmail(opts: {
  employeeEmail: string;
  employeeName: string;
  cycleName: string;
}) {
  const resend = new Resend(process.env.RESEND_API_KEY);
  await resend.emails.send({
    from: FROM,
    to: opts.employeeEmail,
    subject: `[ALAMAH PMS] Manager review submitted for ${opts.cycleName}`,
    html: `
      <p>Hi ${opts.employeeName},</p>
      <p>Your manager has submitted their review for the <strong>${opts.cycleName}</strong> cycle.</p>
      <p>Your performance card is now pending HR finalization.</p>
    `,
  });
}

export async function sendReviewConfirmationEmail(opts: {
  email: string;
  name: string;
  cycleName: string;
}) {
  const resend = new Resend(process.env.RESEND_API_KEY);
  await resend.emails.send({
    from: FROM,
    to: opts.email,
    subject: `[ALAMAH PMS] Self-review submitted — ${opts.cycleName}`,
    html: `
      <p>Hi ${opts.name},</p>
      <p>Your self-review for <strong>${opts.cycleName}</strong> has been successfully submitted.</p>
      <p>Your manager will be notified to complete their review.</p>
    `,
  });
}
