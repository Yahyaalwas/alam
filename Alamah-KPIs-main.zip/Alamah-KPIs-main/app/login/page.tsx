"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useI18n } from "@/lib/i18n/context";
import { loginSchema, type LoginInput } from "@/validators";
import { Button } from "@/components/ui/Button";
import type { AuthUser } from "@/types";

export default function LoginPage() {
  const { t, lang, setLang } = useI18n();
  const router = useRouter();
  const [serverError, setServerError] = useState("");

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<LoginInput>({
    resolver: zodResolver(loginSchema),
  });

  const onSubmit = async (data: LoginInput) => {
    setServerError("");
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!res.ok) {
        setServerError(t("invalidCredentials"));
        return;
      }

      const { user }: { user: AuthUser } = await res.json();
      const dest = user.role === "manager" ? "/dashboard/manager" : "/dashboard/employee";
      router.push(dest);
      router.refresh();
    } catch {
      setServerError(t("errorOccurred"));
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-gray-50 flex flex-col">
      {/* Top bar */}
      <div className="flex justify-between items-center px-6 py-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-[#E8630A] flex items-center justify-center">
            <span className="text-white font-bold text-sm">A</span>
          </div>
          <span className="font-semibold text-gray-900 text-sm">{t("appName")}</span>
        </div>
        <button
          onClick={() => setLang(lang === "en" ? "ar" : "en")}
          className="px-3 py-1.5 text-xs font-medium text-gray-600 hover:text-gray-900 hover:bg-white/80 rounded-md border border-gray-200 transition-colors"
        >
          {lang === "en" ? "العربية" : "English"}
        </button>
      </div>

      {/* Login card */}
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-sm">
          {/* Brand mark */}
          <div className="text-center mb-8">
            <div className="w-14 h-14 rounded-2xl bg-[#E8630A] flex items-center justify-center mx-auto mb-4 shadow-lg shadow-orange-200">
              <span className="text-white font-bold text-2xl">A</span>
            </div>
            <h1 className="text-xl font-bold text-gray-900">{t("loginTitle")}</h1>
            <p className="text-sm text-gray-500 mt-1">Alamah Marketing</p>
          </div>

          <form
            onSubmit={handleSubmit(onSubmit)}
            className="bg-white rounded-2xl border border-gray-100 shadow-xl shadow-gray-100 p-6 space-y-4"
          >
            {serverError && (
              <div className="p-3 rounded-lg bg-red-50 border border-red-100 text-sm text-red-700">
                {serverError}
              </div>
            )}

            <div className="space-y-1">
              <label className="block text-xs font-medium text-gray-700">{t("email")}</label>
              <input
                {...register("email")}
                type="email"
                autoComplete="email"
                placeholder="you@alamahmarketing.com"
                className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E8630A]/30 focus:border-[#E8630A] transition-colors"
              />
              {errors.email && (
                <p className="text-xs text-red-600">{errors.email.message}</p>
              )}
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-medium text-gray-700">{t("password")}</label>
              <input
                {...register("password")}
                type="password"
                autoComplete="current-password"
                placeholder="••••••••"
                className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#E8630A]/30 focus:border-[#E8630A] transition-colors"
              />
              {errors.password && (
                <p className="text-xs text-red-600">{errors.password.message}</p>
              )}
            </div>

            <Button
              type="submit"
              className="w-full"
              size="lg"
              loading={isSubmitting}
            >
              {isSubmitting ? t("loggingIn") : t("login")}
            </Button>
          </form>

          <p className="text-center text-xs text-gray-400 mt-6">
            © 2025 Alamah Marketing — Performance Management System
          </p>
        </div>
      </div>
    </div>
  );
}
