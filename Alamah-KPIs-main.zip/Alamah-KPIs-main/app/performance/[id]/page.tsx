import { redirect, notFound } from "next/navigation";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { PerformanceCardView } from "@/components/performance/PerformanceCardView";

export default async function PerformanceCardPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const session = await getSession();
  if (!session) redirect("/login");

  const { id } = await params;

  const card = await prisma.performanceCard.findUnique({
    where: { id },
    include: {
      user: { select: { id: true, name: true, email: true, department: true, role: true } },
      cycle: true,
      goals: { orderBy: { createdAt: "asc" } },
      competencies: { orderBy: { createdAt: "asc" } },
      ratings: true,
    },
  });

  if (!card) notFound();

  if (session.role === "employee" && card.userId !== session.id) {
    redirect("/dashboard/employee");
  }

  return (
    <PerformanceCardView
      card={JSON.parse(JSON.stringify(card))}
      currentUser={{ id: session.id, role: session.role }}
    />
  );
}
