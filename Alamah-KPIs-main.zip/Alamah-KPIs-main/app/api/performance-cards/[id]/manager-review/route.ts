import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { managerReviewSchema } from "@/validators";
import { sendManagerSubmittedEmail } from "@/lib/email";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (session.role !== "manager") return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { id } = await params;

  const card = await prisma.performanceCard.findUnique({
    where: { id },
    include: { goals: true, competencies: true, cycle: true, user: true },
  });

  if (!card) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (card.currentStage !== "MANAGER_REVIEW") {
    return NextResponse.json({ error: "Card is not in manager review stage" }, { status: 400 });
  }

  const body = await request.json();
  const parsed = managerReviewSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid data", details: parsed.error.flatten() }, { status: 400 });
  }

  const { ratings } = parsed.data;

  const goalIds: string[] = card.goals.map((g: { id: string }) => g.id);
  const compIds: string[] = card.competencies.map((c: { id: string }) => c.id);
  const allTargets = [...goalIds, ...compIds];

  for (const targetId of allTargets) {
    if (!ratings[targetId]) {
      return NextResponse.json({ error: `Missing rating for target ${targetId}` }, { status: 400 });
    }
  }

  await prisma.$transaction(
    allTargets.map((targetId) => {
      const isGoal = goalIds.includes(targetId);
      return prisma.rating.upsert({
        where: { performanceCardId_targetId: { performanceCardId: id, targetId } },
        create: {
          performanceCardId: id,
          targetType: isGoal ? "goal" : "competency",
          targetId,
          managerRating: ratings[targetId].rating,
          managerComment: ratings[targetId].comment,
        },
        update: {
          managerRating: ratings[targetId].rating,
          managerComment: ratings[targetId].comment,
        },
      });
    })
  );

  await prisma.performanceCard.update({
    where: { id },
    data: {
      currentStage: "HR_FINALIZED",
      managerSubmittedAt: new Date(),
    },
  });

  sendManagerSubmittedEmail({
    employeeEmail: card.user.email,
    employeeName: card.user.name,
    cycleName: card.cycle.title,
  }).catch(console.error);

  return NextResponse.json({ success: true });
}
