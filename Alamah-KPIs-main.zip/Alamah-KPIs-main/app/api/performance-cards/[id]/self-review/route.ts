import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { selfReviewSchema } from "@/validators";
import {
  sendReviewConfirmationEmail,
  sendEmployeeSubmittedEmail,
} from "@/lib/email";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (session.role !== "employee") return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { id } = await params;

  const card = await prisma.performanceCard.findUnique({
    where: { id },
    include: { goals: true, competencies: true, cycle: true, user: true },
  });

  if (!card) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (card.userId !== session.id) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  if (card.currentStage !== "SELF_REVIEW") {
    return NextResponse.json({ error: "Self-review already submitted" }, { status: 400 });
  }

  const body = await request.json();
  const parsed = selfReviewSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid data", details: parsed.error.flatten() }, { status: 400 });
  }

  const { ratings } = parsed.data;

  const goalIds: string[] = card.goals.map((g: { id: string }) => g.id);
  const compIds: string[] = card.competencies.map((c: { id: string }) => c.id);
  const allTargets = [...goalIds, ...compIds];

  for (const targetId of allTargets) {
    if (!ratings[targetId]) {
      return NextResponse.json({ error: `Missing rating for target ${targetId}` }, { status: 400 });
    }
  }

  await prisma.$transaction(
    allTargets.map((targetId) => {
      const isGoal = goalIds.includes(targetId);
      return prisma.rating.upsert({
        where: { performanceCardId_targetId: { performanceCardId: id, targetId } },
        create: {
          performanceCardId: id,
          targetType: isGoal ? "goal" : "competency",
          targetId,
          employeeRating: ratings[targetId].rating,
          employeeComment: ratings[targetId].comment,
        },
        update: {
          employeeRating: ratings[targetId].rating,
          employeeComment: ratings[targetId].comment,
        },
      });
    })
  );

  await prisma.performanceCard.update({
    where: { id },
    data: {
      currentStage: "MANAGER_REVIEW",
      employeeSubmittedAt: new Date(),
    },
  });

  const manager = await prisma.user.findFirst({ where: { role: "manager" } });
  if (manager) {
    sendEmployeeSubmittedEmail({
      managerEmail: manager.email,
      managerName: manager.name,
      employeeName: card.user.name,
      cycleName: card.cycle.title,
    }).catch(console.error);
  }
  sendReviewConfirmationEmail({
    email: card.user.email,
    name: card.user.name,
    cycleName: card.cycle.title,
  }).catch(console.error);

  return NextResponse.json({ success: true });
}
