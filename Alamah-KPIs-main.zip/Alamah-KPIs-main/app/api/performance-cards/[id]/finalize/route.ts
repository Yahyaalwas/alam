import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { hrFinalizeSchema } from "@/validators";
import { calculateFinalScore } from "@/lib/score";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (session.role !== "manager") return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { id } = await params;

  const card = await prisma.performanceCard.findUnique({
    where: { id },
    include: { goals: true, competencies: true, ratings: true },
  });

  if (!card) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (card.currentStage !== "HR_FINALIZED" || card.hrFinalizedAt !== null) {
    return NextResponse.json({ error: "Card is not ready for finalization or already finalized" }, { status: 400 });
  }

  const body = await request.json();
  const parsed = hrFinalizeSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid data", details: parsed.error.flatten() }, { status: 400 });
  }

  const { ratings } = parsed.data;

  const goalIds: string[] = card.goals.map((g: { id: string }) => g.id);
  const compIds: string[] = card.competencies.map((c: { id: string }) => c.id);
  const allTargets = [...goalIds, ...compIds];

  for (const targetId of allTargets) {
    if (!ratings[targetId]) {
      return NextResponse.json({ error: `Missing final rating for target ${targetId}` }, { status: 400 });
    }
  }

  await prisma.$transaction(
    allTargets.map((targetId) =>
      prisma.rating.update({
        where: { performanceCardId_targetId: { performanceCardId: id, targetId } },
        data: {
          finalRating: ratings[targetId].rating,
          finalComment: ratings[targetId].comment,
        },
      })
    )
  );

  const updatedRatings = await prisma.rating.findMany({ where: { performanceCardId: id } });
  const finalScore = calculateFinalScore(card.goals, card.competencies, updatedRatings as Parameters<typeof calculateFinalScore>[2], true);

  await prisma.performanceCard.update({
    where: { id },
    data: {
      hrFinalizedAt: new Date(),
      overallFinalScore: finalScore,
    },
  });

  return NextResponse.json({ success: true, finalScore });
}
