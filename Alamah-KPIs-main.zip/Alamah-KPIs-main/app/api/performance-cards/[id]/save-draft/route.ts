import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/db";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;

  const card = await prisma.performanceCard.findUnique({
    where: { id },
    include: { goals: true, competencies: true },
  });

  if (!card) return NextResponse.json({ error: "Not found" }, { status: 404 });

  if (session.role === "employee") {
    if (card.userId !== session.id) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    if (card.currentStage !== "SELF_REVIEW") {
      return NextResponse.json({ error: "Already submitted" }, { status: 400 });
    }
  }

  if (session.role === "manager" && card.currentStage === "SELF_REVIEW") {
    return NextResponse.json({ error: "Employee hasn't submitted yet" }, { status: 400 });
  }

  const body = await request.json();
  const { ratings } = body as { ratings: Record<string, { rating: number; comment: string }> };

  if (!ratings) return NextResponse.json({ error: "No ratings provided" }, { status: 400 });

  const isEmployee = session.role === "employee";
  const goalIds: string[] = card.goals.map((g: { id: string }) => g.id);
  const compIds: string[] = card.competencies.map((c: { id: string }) => c.id);
  const allTargets = [...goalIds, ...compIds];

  await prisma.$transaction(
    Object.entries(ratings)
      .filter(([targetId]) => allTargets.includes(targetId))
      .map(([targetId, data]) => {
        const isGoal = goalIds.includes(targetId);
        return prisma.rating.upsert({
          where: { performanceCardId_targetId: { performanceCardId: id, targetId } },
          create: {
            performanceCardId: id,
            targetType: isGoal ? "goal" : "competency",
            targetId,
            ...(isEmployee ? { employeeRating: data.rating, employeeComment: data.comment } : {}),
            ...(!isEmployee ? { managerRating: data.rating, managerComment: data.comment } : {}),
          },
          update: {
            ...(isEmployee ? { employeeRating: data.rating, employeeComment: data.comment } : {}),
            ...(!isEmployee ? { managerRating: data.rating, managerComment: data.comment } : {}),
          },
        });
      })
  );

  return NextResponse.json({ success: true });
}
