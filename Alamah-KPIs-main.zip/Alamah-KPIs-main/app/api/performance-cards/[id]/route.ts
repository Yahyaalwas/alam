import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/db";

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;

  const card = await prisma.performanceCard.findUnique({
    where: { id },
    include: {
      user: { select: { id: true, name: true, email: true, department: true, role: true } },
      cycle: true,
      goals: { orderBy: { createdAt: "asc" } },
      competencies: { orderBy: { createdAt: "asc" } },
      ratings: true,
    },
  });

  if (!card) return NextResponse.json({ error: "Not found" }, { status: 404 });

  // Employees can only see their own cards
  if (session.role === "employee" && card.userId !== session.id) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  return NextResponse.json({ card });
}
