import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/db";

export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  if (session.role === "manager") {
    const cards = await prisma.performanceCard.findMany({
      include: {
        user: { select: { id: true, name: true, email: true, department: true, role: true } },
        cycle: true,
        goals: true,
        competencies: true,
        ratings: true,
      },
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json({ cards });
  }

  const cards = await prisma.performanceCard.findMany({
    where: { userId: session.id },
    include: {
      user: { select: { id: true, name: true, email: true, department: true, role: true } },
      cycle: true,
      goals: true,
      competencies: true,
      ratings: true,
    },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json({ cards });
}
