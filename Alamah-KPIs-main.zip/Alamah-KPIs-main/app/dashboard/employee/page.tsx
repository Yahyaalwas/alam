import { redirect } from "next/navigation";
import Link from "next/link";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { StageBadge, CycleStatusBadge } from "@/components/ui/Badge";
import { EmployeeDashboardClient } from "@/components/dashboard/EmployeeDashboardClient";

export default async function EmployeeDashboardPage() {
  const session = await getSession();
  if (!session) redirect("/login");
  if (session.role !== "employee") redirect("/dashboard/manager");

  const card = await prisma.performanceCard.findFirst({
    where: { userId: session.id },
    include: {
      cycle: true,
      goals: true,
      competencies: true,
      ratings: true,
    },
    orderBy: { createdAt: "desc" },
  });

  return (
    <EmployeeDashboardClient
      card={card ? JSON.parse(JSON.stringify(card)) : null}
      userId={session.id}
      userName={session.name}
    />
  );
}
