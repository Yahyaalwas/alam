import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { ManagerDashboardClient } from "@/components/dashboard/ManagerDashboardClient";

export default async function ManagerDashboardPage() {
  const session = await getSession();
  if (!session) redirect("/login");
  if (session.role !== "manager") redirect("/dashboard/employee");

  const cards = await prisma.performanceCard.findMany({
    include: {
      user: { select: { id: true, name: true, email: true, department: true, role: true } },
      cycle: true,
      goals: true,
      competencies: true,
      ratings: true,
    },
    orderBy: { createdAt: "desc" },
  });

  return (
    <ManagerDashboardClient
      cards={JSON.parse(JSON.stringify(cards))}
      managerName={session.name}
    />
  );
}
